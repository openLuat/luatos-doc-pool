--- 模块功能：闹钟功能测试(支持开机闹钟和关机闹钟，同时只能存在一个闹钟，如果想实现多个闹钟，等当前闹钟触发后，再次调用闹钟设置接口去配置下一个闹钟).
-- @author openLuat
-- @module alarm.testAlarm
-- @license MIT
-- @copyright openLuat
-- @release 2018.03.14


require "sys"
require"misc"
module(...,package.seeall)


sys.taskInit(function()
    sys.wait(10000)

    log.info("按位取反，输出-6",bit.bnot(5))
    log.info("与,--输出1",bit.band(1,1))
    log.info("或，--输出3",bit.bor(1,2))
    log.info("异或结果为4",bit.bxor(2,3,5))
    log.info("逻辑左移，“100”，输出为4",bit.lshift(1,2))

    log.info("逻辑右移，“001”，输出为1",bit.rshift(4,2))
    log.info("算数右移，左边添加的数与符号有关，输出为0",bit.arshift(2,2))
    log.info("参数是位数，作用是1向左移动两位，打印出4",bit.bit(2))
    log.info("测试位数是否被置1",bit.isset(5,0))--第一个参数是是测试数字，第二个是测试位置。从右向左数0到7。是1返回true，否则返回false，该返回true
    log.info("测试位数是否被置1",bit.isset(5,1))--打印false
    log.info("测试位数是否被置1",bit.isset(5,2))--打印true
    log.info("测试位数是否被置1",bit.isset(5,3))--返回返回false
    log.info("测试位数是否被置0",bit.isclear(5,0))----与上面的相反
    log.info("测试位数是否被置0",bit.isclear(5,1))
    log.info("测试位数是否被置0",bit.isclear(5,2))
    log.info("测试位数是否被置0",bit.isclear(5,3))
    log.info("把0的第0，1，2，3位值为1",bit.set(0,0,1,2,3))--在相应的位数置1，打印15
    log.info("把5的第0，2位置为0",bit.clear(5,0,2))--在相应的位置置0，打印0
    sys.wait(2000)

end)


